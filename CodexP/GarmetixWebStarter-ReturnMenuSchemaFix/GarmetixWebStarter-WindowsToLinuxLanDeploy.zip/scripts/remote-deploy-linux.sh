#!/usr/bin/env bash
set -Eeuo pipefail

ARCHIVE_PATH="${1:?archive path required}"
REMOTE_PATH="${2:?remote path required}"
RELEASE="${3:?release required}"
COMPOSE_FILE="${4:-docker-compose.yml}"
NO_CACHE_API="${5:-false}"
NO_CACHE_ALL="${6:-false}"
SKIP_START="${7:-false}"
INSTALL_DOCKER="${8:-false}"
UPLOAD_ENV="${9:-false}"
UPLOADED_ENV_PATH="${10:-}"

log() { printf '\n[%s] %s\n' "$(date +%H:%M:%S)" "$*"; }

install_docker_ubuntu_debian() {
  if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
    log "Docker and Docker Compose are already installed."
    return 0
  fi

  if [[ "$INSTALL_DOCKER" != "true" ]]; then
    echo "Docker/Docker Compose not found. Re-run with -InstallDocker or install Docker manually on Linux." >&2
    return 1
  fi

  if ! command -v sudo >/dev/null 2>&1; then
    echo "sudo is required for automatic Docker installation." >&2
    return 1
  fi

  if [[ -f /etc/os-release ]]; then
    . /etc/os-release
  fi

  case "${ID:-}" in
    ubuntu|debian)
      log "Installing Docker using distro packages. For production, you may prefer Docker's official repository."
      sudo apt-get update
      sudo apt-get install -y docker.io docker-compose-plugin curl ca-certificates
      sudo systemctl enable --now docker || true
      if ! groups "$USER" | grep -qw docker; then
        sudo usermod -aG docker "$USER" || true
        log "User added to docker group. You may need to log out/in before Docker works without sudo. This deployment will try sudo docker if needed."
      fi
      ;;
    *)
      echo "Automatic Docker installation supports Ubuntu/Debian only. Install Docker manually and run again." >&2
      return 1
      ;;
  esac
}

compose() {
  if docker compose version >/dev/null 2>&1; then
    docker compose -f "$COMPOSE_FILE" "$@"
  elif command -v sudo >/dev/null 2>&1 && sudo docker compose version >/dev/null 2>&1; then
    sudo docker compose -f "$COMPOSE_FILE" "$@"
  else
    echo "docker compose is not available." >&2
    return 1
  fi
}

install_docker_ubuntu_debian

RELEASE_DIR="$REMOTE_PATH/releases/$RELEASE"
CURRENT_LINK="$REMOTE_PATH/current"
SHARED_DIR="$REMOTE_PATH/shared"

log "Creating release directories"
mkdir -p "$RELEASE_DIR" "$SHARED_DIR" "$SHARED_DIR/secrets" "$SHARED_DIR/backups" "$SHARED_DIR/validation-results"

tar -xzf "$ARCHIVE_PATH" -C "$RELEASE_DIR"

if [[ "$UPLOAD_ENV" == "true" && -n "$UPLOADED_ENV_PATH" && -f "$UPLOADED_ENV_PATH" ]]; then
  cp "$UPLOADED_ENV_PATH" "$SHARED_DIR/.env"
fi

if [[ -f "$SHARED_DIR/.env" ]]; then
  cp "$SHARED_DIR/.env" "$RELEASE_DIR/.env"
elif [[ -f "$RELEASE_DIR/.env" ]]; then
  cp "$RELEASE_DIR/.env" "$SHARED_DIR/.env"
elif [[ -f "$RELEASE_DIR/.env.example" ]]; then
  cp "$RELEASE_DIR/.env.example" "$SHARED_DIR/.env"
  cp "$SHARED_DIR/.env" "$RELEASE_DIR/.env"
  log "Created $SHARED_DIR/.env from .env.example. Edit it for production secrets before public use."
fi

rm -rf "$RELEASE_DIR/secrets" "$RELEASE_DIR/backups" "$RELEASE_DIR/validation-results"
ln -s "$SHARED_DIR/secrets" "$RELEASE_DIR/secrets"
ln -s "$SHARED_DIR/backups" "$RELEASE_DIR/backups"
ln -s "$SHARED_DIR/validation-results" "$RELEASE_DIR/validation-results"

ln -sfn "$RELEASE_DIR" "$CURRENT_LINK"
cd "$CURRENT_LINK"

if [[ ! -f "$COMPOSE_FILE" ]]; then
  echo "Compose file '$COMPOSE_FILE' was not found in $CURRENT_LINK" >&2
  exit 1
fi

log "Validating Docker Compose file"
compose config >/dev/null

if [[ "$SKIP_START" == "true" ]]; then
  log "SkipStart requested. Files deployed but services were not started."
  exit 0
fi

if [[ "$NO_CACHE_ALL" == "true" ]]; then
  log "Building all services with --no-cache"
  compose build --no-cache
elif [[ "$NO_CACHE_API" == "true" ]]; then
  log "Building API with --no-cache"
  compose build --no-cache api
fi

log "Starting services"
compose up -d --build

log "Container status"
compose ps || true

log "Waiting for API health"
for i in {1..60}; do
  if curl -fsS http://localhost:5080/api/health >/dev/null 2>&1; then
    log "API health OK"
    break
  fi
  sleep 2
  if [[ "$i" == "60" ]]; then
    echo "API health check failed. Recent API logs:" >&2
    compose logs --tail=120 api >&2 || true
    exit 1
  fi
done

log "Checking web endpoint"
for i in {1..30}; do
  if curl -fsS http://localhost:3000 >/dev/null 2>&1; then
    log "Web endpoint OK"
    break
  fi
  sleep 2
  if [[ "$i" == "30" ]]; then
    echo "Web endpoint did not respond yet. Recent web logs:" >&2
    compose logs --tail=80 web >&2 || true
    exit 1
  fi
done

LAN_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
log "Deployment complete"
echo "Project path: $CURRENT_LINK"
echo "Linux local URL: http://localhost:3000"
if [[ -n "$LAN_IP" ]]; then
  echo "LAN URL: http://$LAN_IP:3000"
  echo "API health: http://$LAN_IP:5080/api/health"
fi
