<#
.SYNOPSIS
  Deploy Garmetix Web from a Windows PC to a Linux machine on the same LAN using SSH/SCP.

.EXAMPLE
  .\scripts\deploy-to-linux-lan.ps1 -LinuxHost 192.168.1.50 -LinuxUser amit -RemotePath /opt/garmetix -NoCacheApi

.EXAMPLE
  .\scripts\deploy-to-linux-lan.ps1 -LinuxHost garmetix-server.local -LinuxUser amit -PrivateKey $env:USERPROFILE\.ssh\id_ed25519 -UseProdCompose
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$LinuxHost,

    [Parameter(Mandatory = $true)]
    [string]$LinuxUser,

    [int]$SshPort = 22,

    [string]$RemotePath = "/opt/garmetix",

    [switch]$UseProdCompose,

    [switch]$NoCacheApi,

    [switch]$NoCacheAll,

    [switch]$SkipStart,

    [switch]$UploadEnv,

    [switch]$InstallDocker,

    [string]$PrivateKey
)

$ErrorActionPreference = "Stop"

function Require-Command {
    param([string]$Name)
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "Required command '$Name' was not found. Install/enable OpenSSH Client and make sure '$Name' is on PATH."
    }
}

Require-Command ssh
Require-Command scp
Require-Command tar

$ProjectRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
$Release = Get-Date -Format "yyyyMMddHHmmss"
$TempDir = Join-Path ([System.IO.Path]::GetTempPath()) "garmetix-lan-deploy-$Release"
New-Item -ItemType Directory -Force -Path $TempDir | Out-Null
$ArchivePath = Join-Path $TempDir "garmetix-web-$Release.tar.gz"
$RemoteTemp = "/tmp/garmetix-lan-deploy-$Release"
$Target = "$LinuxUser@$LinuxHost"
$ComposeFile = if ($UseProdCompose) { "docker-compose.prod.yml" } else { "docker-compose.yml" }

$SshArgs = @()
$ScpArgs = @()
if ($PrivateKey) {
    $SshArgs += @("-i", $PrivateKey)
    $ScpArgs += @("-i", $PrivateKey)
}
$SshArgs += @("-p", "$SshPort", "-o", "ServerAliveInterval=30", "-o", "ServerAliveCountMax=5")
$ScpArgs += @("-P", "$SshPort")

Write-Host "Packaging project from $ProjectRoot" -ForegroundColor Cyan
Push-Location $ProjectRoot
try {
    $TarArgs = @(
        "-czf", $ArchivePath,
        "--exclude=.git",
        "--exclude=node_modules",
        "--exclude=frontend/node_modules",
        "--exclude=frontend/.nuxt",
        "--exclude=frontend/.output",
        "--exclude=backend/**/bin",
        "--exclude=backend/**/obj",
        "--exclude=validation-results",
        "--exclude=backups",
        "--exclude=*.zip",
        "."
    )
    & tar @TarArgs
    if ($LASTEXITCODE -ne 0) { throw "tar packaging failed with exit code $LASTEXITCODE" }
}
finally {
    Pop-Location
}

Write-Host "Testing SSH connection to $Target" -ForegroundColor Cyan
& ssh @SshArgs $Target "echo connected-to-`$(hostname)"
if ($LASTEXITCODE -ne 0) { throw "SSH connection failed. Check LinuxHost, LinuxUser, SshPort, firewall, and SSH service." }

Write-Host "Creating remote temp folder $RemoteTemp" -ForegroundColor Cyan
& ssh @SshArgs $Target "mkdir -p '$RemoteTemp'"
if ($LASTEXITCODE -ne 0) { throw "Could not create remote temp folder." }

Write-Host "Uploading project archive" -ForegroundColor Cyan
& scp @ScpArgs $ArchivePath "$Target`:$RemoteTemp/project.tar.gz"
if ($LASTEXITCODE -ne 0) { throw "SCP upload failed." }

Write-Host "Uploading remote deploy runner" -ForegroundColor Cyan
& scp @ScpArgs (Join-Path $ProjectRoot "scripts/remote-deploy-linux.sh") "$Target`:$RemoteTemp/remote-deploy-linux.sh"
if ($LASTEXITCODE -ne 0) { throw "SCP upload of remote script failed." }

if ($UploadEnv) {
    $LocalEnv = Join-Path $ProjectRoot ".env"
    if (Test-Path $LocalEnv) {
        Write-Host "Uploading local .env to remote shared config" -ForegroundColor Cyan
        & scp @ScpArgs $LocalEnv "$Target`:$RemoteTemp/.env"
        if ($LASTEXITCODE -ne 0) { throw "SCP upload of .env failed." }
    }
    else {
        Write-Warning "-UploadEnv was specified, but local .env was not found. Remote will use existing shared .env or create one from .env.example."
    }
}

$NoCacheApiText = if ($NoCacheApi) { "true" } else { "false" }
$NoCacheAllText = if ($NoCacheAll) { "true" } else { "false" }
$SkipStartText = if ($SkipStart) { "true" } else { "false" }
$InstallDockerText = if ($InstallDocker) { "true" } else { "false" }
$UploadEnvText = if ($UploadEnv) { "true" } else { "false" }

$RemoteCommand = "bash '$RemoteTemp/remote-deploy-linux.sh' '$RemoteTemp/project.tar.gz' '$RemotePath' '$Release' '$ComposeFile' '$NoCacheApiText' '$NoCacheAllText' '$SkipStartText' '$InstallDockerText' '$UploadEnvText' '$RemoteTemp/.env'"

Write-Host "Running remote deployment" -ForegroundColor Cyan
& ssh @SshArgs $Target $RemoteCommand
if ($LASTEXITCODE -ne 0) { throw "Remote deployment failed with exit code $LASTEXITCODE" }

Write-Host "Deployment completed." -ForegroundColor Green
Write-Host "Open the app from Windows using: http://$LinuxHost`:3000" -ForegroundColor Green
Write-Host "API health: http://$LinuxHost`:5080/api/health" -ForegroundColor Green
