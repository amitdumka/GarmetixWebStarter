# Windows to Linux LAN Deployment Notes

This project includes a Windows PowerShell deployment script that copies the current Garmetix Web project from your Windows machine to a Linux machine on the same network and starts it there with Docker Compose.

## Files added

- `scripts/deploy-to-linux-lan.ps1` — run this from Windows.
- `scripts/remote-deploy-linux.sh` — uploaded and executed on the Linux host by the Windows script.

## Requirements

### Windows PC

- PowerShell 5+ or PowerShell 7+.
- OpenSSH Client enabled, so these commands work:
  - `ssh`
  - `scp`
- `tar` available. Windows 10/11 normally includes it.

Check:

```powershell
ssh -V
scp -V
tar --version
```

### Linux machine

- Same LAN/network as Windows.
- SSH server running.
- Docker and Docker Compose plugin installed.

For Ubuntu/Debian, the deployment script can attempt basic Docker installation if you pass `-InstallDocker`.

## First-time Linux SSH setup

From Windows PowerShell:

```powershell
ssh amit@192.168.1.50
```

Replace:

- `amit` with the Linux username.
- `192.168.1.50` with the Linux machine IP.

If SSH fails, install/enable SSH on Linux:

```bash
sudo apt update
sudo apt install -y openssh-server
sudo systemctl enable --now ssh
ip addr
```

## Deploy from Windows to Linux

Run from the project root on Windows:

```powershell
.\scripts\deploy-to-linux-lan.ps1 -LinuxHost 192.168.1.50 -LinuxUser amit -RemotePath /opt/garmetix -NoCacheApi
```

Then open from Windows browser:

```text
http://192.168.1.50:3000
```

API health:

```text
http://192.168.1.50:5080/api/health
```

## With SSH private key

```powershell
.\scripts\deploy-to-linux-lan.ps1 `
  -LinuxHost 192.168.1.50 `
  -LinuxUser amit `
  -PrivateKey "$env:USERPROFILE\.ssh\id_ed25519" `
  -RemotePath /opt/garmetix `
  -NoCacheApi
```

## Upload local `.env`

By default, the Linux server keeps a persistent shared `.env` in:

```text
/opt/garmetix/shared/.env
```

To upload your Windows project `.env` during deployment:

```powershell
.\scripts\deploy-to-linux-lan.ps1 -LinuxHost 192.168.1.50 -LinuxUser amit -UploadEnv -NoCacheApi
```

## Production compose file

```powershell
.\scripts\deploy-to-linux-lan.ps1 -LinuxHost 192.168.1.50 -LinuxUser amit -UseProdCompose -NoCacheApi
```

## Install Docker automatically on Ubuntu/Debian

```powershell
.\scripts\deploy-to-linux-lan.ps1 -LinuxHost 192.168.1.50 -LinuxUser amit -InstallDocker -NoCacheApi
```

The Linux user may need to log out and back in after being added to the Docker group. The script tries `sudo docker compose` when required.

## What the script does

1. Creates a compressed project archive on Windows.
2. Excludes build/cache folders like `.git`, `node_modules`, `.nuxt`, `.output`, `bin`, `obj`, and old ZIPs.
3. Uploads the archive to Linux using `scp`.
4. Creates a versioned release under:

```text
/opt/garmetix/releases/<timestamp>
```

5. Points this symlink to the latest release:

```text
/opt/garmetix/current
```

6. Keeps persistent server files under:

```text
/opt/garmetix/shared/.env
/opt/garmetix/shared/secrets
/opt/garmetix/shared/backups
/opt/garmetix/shared/validation-results
```

7. Runs Docker Compose on Linux.
8. Checks API and web health.
9. Prints the LAN URL.

## Useful remote commands

SSH into Linux:

```powershell
ssh amit@192.168.1.50
```

Check containers:

```bash
cd /opt/garmetix/current
docker compose ps
```

Show API logs:

```bash
cd /opt/garmetix/current
docker compose logs api --tail=200
```

Restart:

```bash
cd /opt/garmetix/current
docker compose down
docker compose up -d --build
```

## Firewall notes

If the app works on Linux locally but not from Windows, allow ports on Linux:

```bash
sudo ufw allow 3000/tcp
sudo ufw allow 5080/tcp
sudo ufw allow 5432/tcp
sudo ufw status
```

Port `5432` should normally stay internal unless you specifically need PostgreSQL from another machine.

## Rollback

List releases:

```bash
ls -la /opt/garmetix/releases
```

Point `current` to an older release:

```bash
sudo ln -sfn /opt/garmetix/releases/OLD_TIMESTAMP /opt/garmetix/current
cd /opt/garmetix/current
docker compose up -d --build
```
