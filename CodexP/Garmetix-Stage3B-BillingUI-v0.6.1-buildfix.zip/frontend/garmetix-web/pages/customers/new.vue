<template><CustomerEntryForm /></template>
